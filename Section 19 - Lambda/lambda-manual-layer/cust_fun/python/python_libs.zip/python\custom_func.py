def cust_fun():
    print("Hello from the deep layers!!")
    return 1